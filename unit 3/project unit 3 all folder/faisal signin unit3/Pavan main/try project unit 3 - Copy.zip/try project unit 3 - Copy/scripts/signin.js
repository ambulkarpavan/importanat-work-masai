 //for password eye
 const togglePassword = document.querySelector('#togglePassword');
 const password = document.querySelector('#id_password');

 togglePassword.addEventListener('click', function (e) {
     // toggle the type attribute
     const type = password.getAttribute('type') === 'password' ? 'text' : 'password';
     password.setAttribute('type', type);
     // toggle the eye slash icon
     this.classList.toggle('fa-eye-slash');
 });
//eye end


//for sigin
let userDetails = JSON.parse(localStorage.getItem("userDetails"))
console.log(userDetails)

let  signinFunction = () =>
{
 console.log("in")
 let email = document.getElementById("email").value 
 let Passwoord = document.getElementById("id_password").value 
 console.log(email)
 let flag = false;

 for(var i=0;i<userDetails.length;i++)
 {
     if(email === userDetails[i].Email && Passwoord === userDetails[i].Password)
     {
         flag = true
     }
 }
 if(flag === true)
 {
     alert("login successful")
     window.location.href="index.html"
 }
 else{
     alert("login failed")
 }
 
}