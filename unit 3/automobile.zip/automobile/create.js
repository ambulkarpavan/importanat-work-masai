
const details={

    Brand:"Tata",
    Type: "Four-wheeler",
    Drive: "rear wheel",
    window: "four",


};

const car1= Object.create(details);
car1.color="black";
car1.name="indigo";
car1.capicity=5
console.log(car1);